import asyncio
from playwright.async_api import async_playwright

async def run():
    async with async_playwright() as p:
        browser = await p.chromium.launch()
        page = await browser.new_page()
        await page.set_viewport_size({"width": 1280, "height": 720})
        await page.goto("file:///home/user/workspace/campus-leaf-recycling.html")
        
        # Wait a bit for animations and fonts
        await page.wait_for_timeout(2000)
        
        slides = await page.locator(".slide").count()
        for i in range(slides):
            await page.screenshot(path=f"/home/user/workspace/slide_{i+1:02d}.png")
            await page.keyboard.press("ArrowDown")
            await page.wait_for_timeout(800)
            
        await browser.close()

asyncio.run(run())